rm(list=ls())
library('plot3D') 
source('trainperceptron.R')
source('yperceptron.R')
s1<-0.4
s2<-0.4
nc<-200
xc1<-matrix(rnorm(nc*2),ncol=2)*s1 + t(matrix((c(2,2)),ncol=nc,nrow=2))
xc2<-matrix(rnorm(nc*2),ncol=2)*s2 + t(matrix((c(4,4)),ncol=nc,nrow=2))
plot(xc1[,1],xc1[,2],col = 'red', xlim = c(0,6),ylim = c(0,6),xlab = 'x_1',ylab='x_2')
par(new=T)
plot(xc2[,1],xc2[,2],col = 'blue', xlim = c(0,6),ylim = c(0,6),xlab = '',ylab='')


xt<-rbind(xc1[(1:round(nc*0.7)),],xc2[(1:round(nc*0.7)),])
yt<-c(rep(0,round(nc*0.7)),rep(1,(nc*0.7)))
xv<-rbind(xc1[(1+round(nc*0.7)):nc,],xc2[(1+round(nc*0.7)):nc,])
yv<-c(rep(0,(nc-round(nc*0.7))),rep(1,(nc-round(nc*0.7))))
retlist<-trainperceptron(xt,yt,0.1,0.01,100,1)
w<-retlist[[1]]

yhat<-rep(-1,length(yv))
for (i in 1:length(yv))
{
  yhat[i]<-yperceptron(xv[i,],w,1)
}
acc<-length(which(yhat==yv))/length(yv)
print(acc)
#Imprimindo a matriz de confusão
table(yv,yhat)