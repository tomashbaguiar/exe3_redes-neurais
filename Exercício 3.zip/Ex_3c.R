####### Exercicio Aula 4 - Avaliacao do erro do ypercetron  ##############

rm(list=ls())
source('trainperceptron.R')
source('yperceptronmatrix.R')
#carregando dados iris
data(iris)

#numero de amostras para treinamento
ntrain1<-50*0.7
ntrain2<-100*0.7

#selecionando dados iris para a classificao da classe 1 em relacao as classes 2 e 3,
xc1<-iris[1:50,1:4]
xc2<-iris[51:150,1:4]

#geracao e selecao de amostras aleatorias 
seqc1<-sample(dim(xc1)[1])
seqc2<-sample(dim(xc2)[1])

#selecao das amostras aleatorias para treinamento
xc1t<-xc1[seqc1[1:ntrain1],]
yc1t<-matrix(0,nrow=ntrain1)
xc2t<-xc2[seqc2[1:ntrain2],]
yc2t<-matrix(1,nrow=ntrain2)

#seleciona o restante das amostras aleatorias geradas para validação
xc1v<-xc1[seqc1[(ntrain1+1):50],]
yc1v<-matrix(0,nrow=(50-ntrain1))
xc2v<-xc2[seqc2[(ntrain2+1):100],]
yc2v<-matrix(1,nrow=(100-ntrain2))

#concatena as amotras de treinamento das classes para entrar no trainperceptron
xt<-as.matrix(rbind(xc1t,xc2t))
yt<-rbind(yc1t,yc2t)

#faz-se o treinamento do perceptron
retlist<-trainperceptron(xt,yt,0.1,0.01,100,1)

#concatena as amostras de validação
xv<-as.matrix(rbind(xc1v,xc2v))
yv<-rbind(yc1v,yc2v)

#extrai os parametros w da lista de retorno do trainperceptron
wt<-retlist[[1]]

#avalia as amostras de teste
yhat<-yperceptronmatrix(xv,wt,1)

#calculo do erro
erro<-(length(yv)-length(which(yhat==yv)))/length(yv)
erro_percentual<-erro*100

#Imprimindo a matriz de confusão
table(yv,yhat)

